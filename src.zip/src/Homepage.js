import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom



function HomePage() {
  return (
    <div>
      <header>
        <nav>
          <div className="container">
            <h1>AutoPen</h1>
            <ul>
              <li><a href="#features">Features</a></li>
              <li><Link to="/about">About</Link></li> {/* Use Link to navigate to "/about" */}
              <li><a href="#contact">Contact</a></li>
              {/* You can add more navigation links as needed */}
            </ul>
            <Link to="/login" className="login-button">Login</Link> {/* Link to the login page */}
          </div>
        </nav>
      </header>

      <section id="hero">
        <div className="container">
          <h2>Revolutionize Your Security with AutoPen</h2>
          <p>Automated, Comprehensive, and Adaptive Penetration Testing</p>
          <a href="#features" className="cta-button">Learn More</a>
        </div>
      </section>

      <section id="features">
        <div className="container">
          <h2>Key Features</h2>
          <div className="feature">
            <img src="security-icon.png" alt="Security Icon" />
            <h3>Enhanced Security</h3>
            <p>Identify and rectify vulnerabilities in your networks and systems.</p>
          </div>
          <div className="feature">
            <img src="speed-icon.png" alt="Speed Icon" />
            <h3>Quick and Efficient</h3>
            <p>Rapidly scan and analyze large volumes of data for faster results.</p>
          </div>
          <div className="feature">
            <img src="adapt-icon.png" alt="Adapt Icon" />
            <h3>Adaptive Testing</h3>
            <p>Stay ahead of evolving threats with machine learning.</p>
          </div>
        </div>
      </section>

      <section id="about">
        <div className="container">
          <h2>About Us</h2>
          <p>AutoPen is a leading provider of AI-powered penetration testing solutions, dedicated to helping businesses secure their digital assets.</p>
        </div>
      </section>

      <section id="contact">
        <div className="container">
          <h2>Contact Us</h2>
          <p>If you have any questions or inquiries, please feel free to contact our team.</p>
          <a href="contact.html" className="cta-button">Contact Us</a>
        </div>
      </section>

      <footer>
        <div className="container">
          <p>&copy; 2023 AutoPen. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default HomePage;