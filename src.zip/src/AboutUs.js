// AboutUs.js
import React from 'react';

function AboutUs() {
  return (
    <div className="container">
      <h2>About Us</h2>
      <p>AutoPen is a leading provider of AI-powered penetration testing solutions, dedicated to helping businesses secure their digital assets.</p>
    </div>
  );
}

export default AboutUs;